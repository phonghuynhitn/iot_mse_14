package com.example.demoiot02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;

import android.graphics.Color;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.ValueFormatter;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {
    MQTTHelper mqttHelper;
    private TextView serverTextView;
    private TextView temperatureHumidityTextView;
    private TextView temperatureTextView;
    private TextView humidityTextView;
    private TextView recommendationTextView;
    private ImageView temperatureIconImageView;
    private ImageView humidityIconImageView;
    private ToggleButton airConditionerToggleButton;
    private ToggleButton dehumidifierToggleButton;
    private ToggleButton lightToggleButton;
    private BarChart tempChart;
    private BarChart humiChart;


    private void saveTemperatureToDatabase(String time, float temperature) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TIME, time);
        values.put(DatabaseHelper.COLUMN_TEMPERATURE, temperature);

        db.insert(DatabaseHelper.TABLE_NAME, null, values);

        db.close();
    }

    private String getCurrentTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(calendar.getTime());
    }

    private void setupChart() {
        // Cấu hình biểu đồ
        tempChart.setDrawBarShadow(false);
        tempChart.setDrawValueAboveBar(true);
        tempChart.getDescription().setEnabled(false);
        tempChart.setPinchZoom(false);
        tempChart.setDrawGridBackground(false);

        XAxis xAxis = tempChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // set minimum axis-step (interval) to 1
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // Convert float value to timestamp string
                return getTimestampString(value);
            }
        });

        YAxis leftAxis = tempChart.getAxisLeft();
        leftAxis.setLabelCount(5, false);
        leftAxis.setSpaceTop(20f);
        leftAxis.setAxisMinimum(0f);

        tempChart.getAxisRight().setEnabled(false);
    }

    private void loadDataToChart() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>(); // Tạo một danh sách để lưu trữ nhãn trên trục x

        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME,
                new String[]{DatabaseHelper.COLUMN_TIME, DatabaseHelper.COLUMN_TEMPERATURE},
                null, null, null, null, null);

        int index = 0;

        if (cursor.moveToFirst()) {
            do {
                String timeString = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TIME));
                float temperature = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper.COLUMN_TEMPERATURE));

                // Lưu dữ liệu nhiệt độ vào danh sách BarEntry
                entries.add(new BarEntry(index, temperature));

                // Lưu dữ liệu thời gian vào danh sách nhãn
                labels.add(timeString);

                index++;
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        BarDataSet dataSet = new BarDataSet(entries, "Temperature");
        BarData barData = new BarData(dataSet);

        // Cấu hình nhãn trên trục x
        XAxis xAxis = tempChart.getXAxis();
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // Đảm bảo rằng chỉ số không vượt quá phạm vi của danh sách nhãn
                int index = (int) value;
                if (index >= 0 && index < labels.size()) {
                    return labels.get(index);
                } else {
                    return ""; // Trả về chuỗi trống nếu chỉ số nằm ngoài phạm vi danh sách nhãn
                }
            }
        });

        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); // Cấu hình vị trí của trục x

        barData.setBarWidth(0.8f);
        tempChart.setData(barData);
        tempChart.invalidate();
    }

    private String getTimestampString(float value) {
        // Định dạng giá trị trục X dưới dạng HH:mm
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        long timestampMillis = (long) value; // Giá trị float là timestamp
        Date date = new Date(timestampMillis);
        return sdf.format(date);
    }


    private long convertTimeStringToTimestamp(String timeString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date date = sdf.parse(timeString);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }
    private void setupHumidityChart() {
        humiChart.setDrawBarShadow(false);
        humiChart.setDrawValueAboveBar(true);
        humiChart.getDescription().setEnabled(false);
        humiChart.setPinchZoom(false);
        humiChart.setDrawGridBackground(false);

        XAxis xAxis = humiChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // set minimum axis-step (interval) to 1
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // Convert float value to timestamp string
                return getTimestampString(value);
            }
        });

        YAxis leftAxis = humiChart.getAxisLeft();
        leftAxis.setLabelCount(5, false);
        leftAxis.setSpaceTop(20f);
        leftAxis.setAxisMinimum(0f);

        humiChart.getAxisRight().setEnabled(false);
    }

    private void saveHumidityToDatabase(String time, float humidity) {
        DatabaseHelper2 dbHelper = new DatabaseHelper2(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper2.COLUMN_TIME, time);
        values.put(DatabaseHelper2.COLUMN_HUMIDITY, humidity);

        db.insert(DatabaseHelper2.TABLE_NAME, null, values);

        db.close();
    }

    private void loadHumidityDataToChart() {
        DatabaseHelper2 dbHelper = new DatabaseHelper2(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>(); // Tạo một danh sách để lưu trữ nhãn trên trục x

        Cursor cursor = db.query(DatabaseHelper2.TABLE_NAME,
                new String[]{DatabaseHelper2.COLUMN_TIME, DatabaseHelper2.COLUMN_HUMIDITY},
                null, null, null, null, null);

        int index = 0;

        if (cursor.moveToFirst()) {
            do {
                String timeString = cursor.getString(cursor.getColumnIndex(DatabaseHelper2.COLUMN_TIME));
                float temperature = cursor.getFloat(cursor.getColumnIndex(DatabaseHelper2.COLUMN_HUMIDITY));

                // Lưu dữ liệu nhiệt độ vào danh sách BarEntry
                entries.add(new BarEntry(index, temperature));

                // Lưu dữ liệu thời gian vào danh sách nhãn
                labels.add(timeString);

                index++;
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        BarDataSet dataSet = new BarDataSet(entries, "Humidity");
        BarData barData = new BarData(dataSet);

        // Cấu hình nhãn trên trục x
        XAxis xAxis = humiChart.getXAxis();
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // Đảm bảo rằng chỉ số không vượt quá phạm vi của danh sách nhãn
                int index = (int) value;
                if (index >= 0 && index < labels.size()) {
                    return labels.get(index);
                } else {
                    return ""; // Trả về chuỗi trống nếu chỉ số nằm ngoài phạm vi danh sách nhãn
                }
            }
        });

        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); // Cấu hình vị trí của trục x

        barData.setBarWidth(0.8f);
        humiChart.setData(barData);
        humiChart.invalidate();
    }

    TextView txtTemp, txtHumi, txtTempPredict;
    ToggleButton btnLED, btnDEHUMI, btnAIRCON;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtTemp = findViewById(R.id.temperatureTextView);
        txtHumi = findViewById(R.id.humidityTextView);
        txtTempPredict = findViewById(R.id.recommendationTextView);
        btnLED = findViewById(R.id.lightToggleButton);
        btnAIRCON = findViewById(R.id.airConditionerToggleButton);
        btnDEHUMI = findViewById(R.id.dehumidifierToggleButton);
        temperatureHumidityTextView = findViewById(R.id.temperatureHumidityTextView);
        tempChart = findViewById(R.id.tempchart);
        humiChart = findViewById(R.id.humichart);
        setupChart();
        loadDataToChart();
        loadHumidityDataToChart();
        setupHumidityChart();


        btnLED.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isOn = btnLED.isChecked();
                if (isOn) {
                    sendDataMQTT("mse14-group2/feeds/relay02", "1");
                } else {
                    sendDataMQTT("mse14-group2/feeds/relay02", "0");
                }
            }
        });

        btnAIRCON.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isOn = btnAIRCON.isChecked();
                if (isOn) {
                    sendDataMQTT("mse14-group2/feeds/relay03", "1");
                } else {
                    sendDataMQTT("mse14-group2/feeds/relay03", "0");
                }
            }
        });

        btnDEHUMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isOn = btnDEHUMI.isChecked();
                if (isOn) {
                    sendDataMQTT("mse14-group2/feeds/relay04", "1");
                } else {
                    sendDataMQTT("mse14-group2/feeds/relay04", "0");
                }
            }
        });
        startMQTT();
    }

    public void sendDataMQTT(String topic, String value){
        MqttMessage msg = new MqttMessage();
        msg.setId(1234);
        msg.setQos(0);
        msg.setRetained(true);

        byte[] b = value.getBytes(Charset.forName("UTF-8"));
        msg.setPayload(b);

        try {
            mqttHelper.mqttAndroidClient.publish(topic, msg);
        }catch (MqttException e){
        }
    }

    public void startMQTT(){
        mqttHelper = new MQTTHelper(this);
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
            }
            @Override
            public void connectionLost(Throwable cause) {
            }
            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.d("TEST", topic + "***" + message.toString());
                Log.d("MQTT", "Received message on topic: " + topic);
                Log.d("MQTT", "Message content: " + new String(message.getPayload()));
                if (topic.contains("predict_temperature_content")){
                    String receivedText = new String(message.getPayload()); // Chuyển dữ liệu nhận được sang chuỗi
                    // Hiển thị dữ liệu lên txtTempPredict
                    txtTempPredict.setText(receivedText);
                } else if(topic.contains("moisture")){
                    float humidity = Float.parseFloat(message.toString()) / 100;
                    txtHumi.setText(humidity + "%");
                    saveHumidityToDatabase(getCurrentTime(), humidity);
                } else if(topic.contains("temperature")) {
                    float temperature = Float.parseFloat(message.toString()) / 100;
                    txtTemp.setText(temperature + "°C");
                    saveTemperatureToDatabase(getCurrentTime(), temperature);
                } else if (topic.contains("relay02")) {
                    // Check the message content to determine the state
                    boolean isOn = message.toString().equals("1");
                    // Set the state of btnLED
                    btnLED.setChecked(isOn);
                    if (isOn) {
                        btnLED.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_light, 0, 0);
                        btnLED.setTextColor(0xFF556B2F); // Set text color to green
                    } else {
                        btnLED.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_light_off, 0, 0);
                        btnLED.setTextColor(0xFF000000); // Set text color to red
                    }
                } else if (topic.contains("relay03")) {
                    // Check the message content to determine the state
                    boolean isOn = message.toString().equals("1");
                    // Set the state of btnAIRCON
                    btnAIRCON.setChecked(isOn);
                    if (isOn) {
                        btnAIRCON.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_airconditioner, 0, 0);
                        btnAIRCON.setTextColor(0xFF556B2F); // Set text color to green
                    } else {
                        btnAIRCON.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_air_conditioner_off, 0, 0);
                        btnAIRCON.setTextColor(0xFF000000); // Set text color to red
                    }
                } else if (topic.contains("relay04")) {
                    // Check the message content to determine the state
                    boolean isOn = message.toString().equals("1");
                    // Set the state of btnDEHUMI
                    btnDEHUMI.setChecked(isOn);
                    if (isOn) {
                        btnDEHUMI.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_dehumi_on, 0, 0);
                        btnDEHUMI.setTextColor(0xFF556B2F); // Set text color to green
                    } else {
                        btnDEHUMI.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_dehumi_off, 0, 0);
                        btnDEHUMI.setTextColor(0xFF000000); // Set text color to red
                    }
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

    }
}